<?php
return array (
  'app_version' => 'v5.0.12',
  'full_app_version' => 'v5.0.12 - build 5705-gf1d0d1bfe',
  'build_version' => '5705',
  'prerelease_version' => '',
  'hash_version' => 'gf1d0d1bfe',
  'full_hash' => 'v5.0.12-8-gf1d0d1bfe',
  'branch' => 'master',
);